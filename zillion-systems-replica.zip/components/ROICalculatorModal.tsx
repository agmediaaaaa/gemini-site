import React, { useState, useEffect } from 'react';
import { X, DollarSign, Activity, Calculator, Percent, Users } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface ROICalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ROICalculatorModal: React.FC<ROICalculatorModalProps> = ({ isOpen, onClose }) => {
  const [retainer, setRetainer] = useState<number>(1000);
  const [dealSize, setDealSize] = useState<number>(10000);
  const [closeRate, setCloseRate] = useState<number>(25);

  // Enforce minimum retainer of 750 on blur
  const handleRetainerBlur = () => {
    if (retainer < 750) {
      setRetainer(750);
    }
  };

  const handleCloseRateBlur = () => {
    if (closeRate < 1) setCloseRate(1);
    if (closeRate > 100) setCloseRate(100);
  };

  // --- CALCULATION LOGIC ---
  
  // 1. Investment = Retainer (Min 750 enforced in logic for display safety)
  const investment = Math.max(retainer, 750);
  
  // 2. Expected Closes = 1 (Benchmark)
  const expectedCloses = 1;

  // 3. Revenue = DealSize * 1
  const revenue = dealSize * expectedCloses;

  // 4. Net Profit = Revenue - Investment
  const profit = revenue - investment;

  // 5. ROI % = (Net Profit / Investment) * 100
  const roi = investment > 0 ? (profit / investment) * 100 : 0;

  // 6. Break-Even Deals = CEIL(Investment / DealSize)
  const breakEvenDeals = dealSize > 0 ? Math.ceil(investment / dealSize) : 0;
  
  // 7. Break-Even Revenue = BreakEvenDeals * DealSize (Revenue needed to cover costs)
  const breakEvenRevenue = breakEvenDeals * dealSize;

  // 8. Leads (Conversations) Needed for 1 Deal = 1 / (CloseRate / 100)
  const leadsNeeded = closeRate > 0 ? Math.ceil(1 / (closeRate / 100)) : 0;

  // 9. Leads Needed for Break Even
  const breakEvenLeads = closeRate > 0 ? Math.ceil(breakEvenDeals / (closeRate / 100)) : 0;

  // --- RECOMMENDATION LOGIC ---
  let recommendationColor = "text-brand-red";
  let recommendationBorder = "border-brand-red/30";
  let recommendationBg = "bg-brand-red/10";
  let recommendationText = "Not Viable";
  let recommendationSubtext = "Suggest offer/pricing upgrades";

  if (roi >= 200) {
    recommendationColor = "text-emerald-500";
    recommendationBorder = "border-emerald-500/30";
    recommendationBg = "bg-emerald-500/10";
    recommendationText = "Excellent";
    recommendationSubtext = "Celebrate strong profitability";
  } else if (roi >= 100) {
    recommendationColor = "text-emerald-400";
    recommendationBorder = "border-emerald-400/30";
    recommendationBg = "bg-emerald-400/10";
    recommendationText = "Good";
    recommendationSubtext = "Strong return — scale investment";
  } else if (roi > 0) {
    recommendationColor = "text-yellow-500";
    recommendationBorder = "border-yellow-500/30";
    recommendationBg = "bg-yellow-500/10";
    recommendationText = "Low but Positive";
    recommendationSubtext = "Suggest improving close rates or deal value";
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center px-4 py-4 md:py-8">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-sm"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-2xl bg-[#0a0a0a] border border-white/10 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
          >
            {/* Header */}
            <div className="p-5 md:p-6 border-b border-white/5 flex justify-between items-center bg-white/5 flex-shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-brand-red/10 flex items-center justify-center text-brand-red border border-brand-red/20 flex-shrink-0">
                  <Calculator size={20} />
                </div>
                <div>
                  <h2 className="text-lg md:text-xl font-bold text-white">ROI Calculator</h2>
                  <p className="text-xs text-gray-400">Estimate your potential returns</p>
                </div>
              </div>
              <button 
                onClick={onClose} 
                className="text-gray-400 hover:text-white transition-colors p-2 hover:bg-white/10 rounded-full"
              >
                <X size={20} />
              </button>
            </div>

            <div className="p-5 md:p-8 overflow-y-auto">
              <div className="grid md:grid-cols-2 gap-8">
                {/* Inputs */}
                <div className="space-y-5">
                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">Monthly Hiring Signal Engine Investment ($)</label>
                    <div className="relative group">
                      <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-brand-red transition-colors" size={16} />
                      <input
                        type="number"
                        value={retainer}
                        onChange={(e) => setRetainer(Number(e.target.value))}
                        onBlur={handleRetainerBlur}
                        className="w-full bg-black border border-white/10 rounded-xl py-3 pl-10 pr-4 text-white focus:border-brand-red focus:ring-1 focus:ring-brand-red outline-none transition-all"
                      />
                    </div>
                    <p className="text-xs text-gray-500 mt-1 ml-1">Minimum allowed: $750</p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">Average Deal Size ($)</label>
                    <div className="relative group">
                      <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-brand-red transition-colors" size={16} />
                      <input
                        type="number"
                        value={dealSize}
                        onChange={(e) => setDealSize(Number(e.target.value))}
                        className="w-full bg-black border border-white/10 rounded-xl py-3 pl-10 pr-4 text-white focus:border-brand-red focus:ring-1 focus:ring-brand-red outline-none transition-all"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">Close Rate (%)</label>
                    <div className="relative group">
                      <Percent className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-brand-red transition-colors" size={16} />
                      <input
                        type="number"
                        value={closeRate}
                        onChange={(e) => setCloseRate(Number(e.target.value))}
                        onBlur={handleCloseRateBlur}
                        className="w-full bg-black border border-white/10 rounded-xl py-3 pl-10 pr-4 text-white focus:border-brand-red focus:ring-1 focus:ring-brand-red outline-none transition-all"
                      />
                    </div>
                    <p className="text-xs text-gray-500 mt-1 ml-1">Benchmark: 20-30%</p>
                  </div>

                  {/* Recommendation Box */}
                  <div className={`p-4 rounded-xl border ${recommendationBorder} ${recommendationBg} mt-6`}>
                     <div className="flex items-center gap-2 mb-1">
                        <Activity size={16} className={recommendationColor} />
                        <span className={`font-bold uppercase text-sm ${recommendationColor}`}>{recommendationText}</span>
                     </div>
                     <p className="text-gray-300 text-sm">{recommendationSubtext}</p>
                  </div>
                </div>

                {/* Results */}
                <div className="bg-white/5 rounded-2xl p-6 border border-white/5 flex flex-col justify-between relative overflow-hidden mt-4 md:mt-0">
                   <div className="absolute top-0 right-0 w-32 h-32 bg-brand-red/5 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none"></div>
                   
                   <div className="space-y-6 relative z-10">
                      <div>
                          <p className="text-sm text-gray-400 mb-1">Expected Monthly Revenue</p>
                          <p className="text-3xl font-bold text-white">${revenue.toLocaleString()}</p>
                          <p className="text-[10px] text-gray-500 uppercase tracking-wider">Based on 1 closed deal/mo</p>
                      </div>
                      
                      <div className="pt-4 border-t border-white/10">
                          <p className="text-sm text-gray-400 mb-1">Net Profit</p>
                          <p className={`text-2xl font-bold ${profit > 0 ? 'text-emerald-400' : 'text-brand-red'}`}>
                            ${profit.toLocaleString()}
                          </p>
                      </div>

                      <div className="pt-4 border-t border-white/10">
                          <p className="text-sm text-gray-400 mb-1">Return on Investment (ROI)</p>
                          <p className={`text-4xl font-bold ${recommendationColor}`}>
                             {roi.toFixed(0)}%
                          </p>
                      </div>
                   </div>

                   <div className="mt-6 pt-4 border-t border-white/10 grid grid-cols-2 gap-4 relative z-10">
                      <div>
                          <p className="text-[10px] uppercase tracking-wider text-gray-500 mb-1">Conv. Needed</p>
                          <div className="flex items-center gap-1.5">
                            <Users size={14} className="text-gray-400" />
                            <p className="text-lg font-semibold text-white">{leadsNeeded}</p>
                          </div>
                          <p className="text-[9px] text-gray-600">For 1 deal</p>
                      </div>
                      <div>
                          <p className="text-[10px] uppercase tracking-wider text-gray-500 mb-1">Break-Even</p>
                          <p className="text-lg font-semibold text-white">{breakEvenDeals} Deal{breakEvenDeals !== 1 ? 's' : ''}</p>
                          <p className="text-[9px] text-gray-600">${breakEvenRevenue.toLocaleString()} rev</p>
                      </div>
                   </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};