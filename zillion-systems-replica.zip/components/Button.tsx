import React from 'react';
import { ArrowRight } from 'lucide-react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline';
  withIcon?: boolean;
  href?: string;
  target?: string;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  withIcon = false,
  className = '',
  href,
  target,
  ...props 
}) => {
  const baseStyles = "inline-flex items-center justify-center px-8 py-4 text-base font-bold rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-black cursor-pointer";
  
  const variants = {
    primary: "btn-liquid-glass text-white focus:ring-brand-red",
    secondary: "bg-white text-black hover:bg-gray-200 focus:ring-white transition-all duration-300 transform hover:-translate-y-1",
    outline: "btn-liquid-glass-outline text-white focus:ring-white"
  };

  const combinedClassName = `${baseStyles} ${variants[variant]} ${className}`;

  if (href) {
    return (
      <a 
        href={href}
        target={target}
        className={combinedClassName}
      >
        {children}
        {withIcon && <ArrowRight className="ml-2 w-5 h-5" />}
      </a>
    );
  }

  return (
    <button 
      className={combinedClassName}
      {...props}
    >
      {children}
      {withIcon && <ArrowRight className="ml-2 w-5 h-5" />}
    </button>
  );
};