import React, { useState, useEffect } from 'react';

interface TypewriterProps {
  words: string[];
  typingSpeed?: number;
  deletingSpeed?: number;
  pauseDuration?: number;
  className?: string;
}

export const Typewriter: React.FC<TypewriterProps> = ({ 
  words, 
  typingSpeed = 100, 
  deletingSpeed = 50, 
  pauseDuration = 2000,
  className = ""
}) => {
  const [text, setText] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);
  const [loopNum, setLoopNum] = useState(0);

  useEffect(() => {
    const i = loopNum % words.length;
    const fullText = words[i];

    const type = () => {
      setText(current => isDeleting 
        ? fullText.substring(0, current.length - 1) 
        : fullText.substring(0, current.length + 1)
      );
    };

    const speed = isDeleting ? deletingSpeed : typingSpeed;

    if (!isDeleting && text === fullText) {
      // If there's only one word, stop after typing it out
      if (words.length === 1) {
        return;
      }
      const timeout = setTimeout(() => setIsDeleting(true), pauseDuration);
      return () => clearTimeout(timeout);
    }

    if (isDeleting && text === '') {
      setIsDeleting(false);
      setLoopNum(l => l + 1);
      return;
    }

    const timeout = setTimeout(type, speed);
    return () => clearTimeout(timeout);

  }, [text, isDeleting, loopNum, words, typingSpeed, deletingSpeed, pauseDuration]);

  return (
    <span className="inline-flex items-center">
      <span className={className}>{text}</span>
      <span className="w-1 md:w-2 h-8 md:h-16 bg-brand-red ml-1 animate-pulse" />
    </span>
  );
};