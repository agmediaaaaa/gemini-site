import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { TimelineStep } from '../types';

interface TimelineProps {
  steps: TimelineStep[];
}

export const Timeline: React.FC<TimelineProps> = ({ steps }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start center", "end center"]
  });

  // Transform scroll progress to height percentage
  const scaleY = useTransform(scrollYProgress, [0, 1], [0, 1]);

  return (
    <div ref={containerRef} className="relative max-w-5xl mx-auto px-4 py-12">
      {/* Central Line Container */}
      <div className="absolute left-8 md:left-1/2 top-0 bottom-0 w-[2px] bg-gray-800 transform md:-translate-x-1/2 origin-top rounded-full overflow-hidden">
          {/* Animated Progress Line */}
          <motion.div 
            style={{ scaleY, transformOrigin: "top" }}
            className="w-full h-full bg-gradient-to-b from-brand-red via-red-500 to-brand-red shadow-[0_0_10px_rgba(220,38,38,0.8)]"
          />
      </div>

      <div className="space-y-24 md:space-y-32 relative z-10">
        {steps.map((step, index) => (
          <div key={step.number} className={`flex flex-col md:flex-row items-center ${index % 2 === 0 ? 'md:flex-row-reverse' : ''} group`}>
            
            {/* Content Side */}
            <div className="w-full md:w-1/2 pl-20 md:pl-0 md:px-16 mb-4 md:mb-0 relative">
              <motion.div
                initial={{ opacity: 0, x: index % 2 === 0 ? 50 : -50, rotateY: index % 2 === 0 ? -10 : 10 }}
                whileInView={{ opacity: 1, x: 0, rotateY: 0 }}
                viewport={{ once: true, margin: "-10%" }}
                transition={{ duration: 0.8, type: "spring", bounce: 0.4 }}
                className={`bg-black/40 backdrop-blur-md border border-white/10 p-8 rounded-2xl shadow-2xl hover:border-brand-red/30 transition-all duration-500 group-hover:shadow-[0_0_30px_rgba(220,38,38,0.1)] relative overflow-hidden ${index % 2 === 0 ? 'md:text-left' : 'md:text-right'}`}
              >
                {/* Card Glow Effect */}
                <div className="absolute -inset-full bg-gradient-to-r from-transparent via-white/5 to-transparent group-hover:translate-x-full transition-transform duration-1000 ease-in-out"></div>

                <div className={`inline-flex items-center px-4 py-1.5 rounded-full bg-brand-red/10 border border-brand-red/20 text-xs font-bold text-brand-red tracking-wider mb-4 uppercase ${index % 2 !== 0 && 'md:ml-auto'}`}>
                  {step.detail}
                </div>
                
                <h3 className="text-3xl font-bold text-white mb-3 leading-tight">{step.title}</h3>
                <p className="text-gray-400 leading-relaxed text-lg">{step.description}</p>
              </motion.div>
            </div>

            {/* Center Point Node */}
            <div className="absolute left-8 md:left-1/2 transform -translate-x-1/2 flex items-center justify-center z-20">
               <motion.div 
                 initial={{ scale: 0, opacity: 0 }}
                 whileInView={{ scale: 1, opacity: 1 }}
                 viewport={{ once: true }}
                 transition={{ delay: 0.2, duration: 0.4 }}
                 className="w-14 h-14 rounded-full bg-black border-4 border-gray-800 group-hover:border-brand-red transition-colors duration-500 flex items-center justify-center shadow-[0_0_20px_rgba(0,0,0,1)] relative"
               >
                  <div className="absolute inset-0 rounded-full bg-brand-red/20 blur-lg opacity-0 group-hover:opacity-100 transition-opacity"></div>
                  <span className="text-xl font-bold text-white">{step.number}</span>
               </motion.div>
            </div>
            
            {/* Empty Side for layout balance */}
            <div className="w-full md:w-1/2 hidden md:block"></div>
          </div>
        ))}
      </div>
    </div>
  );
};