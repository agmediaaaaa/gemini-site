import React from 'react';
import { motion } from 'framer-motion';
import { HiringSignal } from '../types';
import { Bell, TrendingUp, Building, Users, Globe, AlertCircle, Star, Briefcase, DollarSign } from 'lucide-react';

const iconMap: Record<string, any> = {
  'briefcase': Briefcase,
  'growth': TrendingUp,
  'building': Building,
  'alert': Bell, 
  'users': Users,
  'globe': Globe,
  'star': Star,
  'dollar': DollarSign
};

interface SignalCardProps {
  signal: HiringSignal;
  index: number;
}

export const SignalCard: React.FC<SignalCardProps> = ({ signal, index }) => {
  const Icon = iconMap[signal.icon] || Bell;

  return (
    <motion.div
      initial={{ opacity: 0, x: 20, scale: 0.95 }}
      whileInView={{ opacity: 1, x: 0, scale: 1 }}
      viewport={{ once: false, margin: "-20px" }}
      transition={{ duration: 0.4, delay: index * 0.1 }}
      className="group relative overflow-hidden rounded-2xl bg-black/60 backdrop-blur-xl border border-white/10 p-4 shadow-lg mb-3 mx-2"
    >
      {/* Glowing side accent */}
      <div className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-brand-red to-red-900 rounded-l-full"></div>
      
      <div className="flex gap-3 items-start pl-2">
        <div className="flex-shrink-0 mt-0.5">
           <div className="w-8 h-8 rounded-lg bg-red-900/20 border border-red-500/20 flex items-center justify-center text-brand-red shadow-[0_0_10px_rgba(220,38,38,0.2)]">
              <Icon size={16} />
           </div>
        </div>
        <div className="flex-1 min-w-0">
            <div className="flex justify-between items-center mb-1">
                <h3 className="font-semibold text-white text-sm truncate pr-2">{signal.title}</h3>
                <span className="text-[9px] font-semibold text-gray-400 bg-white/5 px-1.5 py-0.5 rounded border border-white/5">NOW</span>
            </div>
            <p className="text-gray-400 text-xs leading-relaxed line-clamp-2">
                {signal.description}
            </p>
        </div>
      </div>
    </motion.div>
  );
};