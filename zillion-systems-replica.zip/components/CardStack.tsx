import React from 'react';
import { motion } from 'framer-motion';
import { CaseStudy } from '../types';
import { Quote } from 'lucide-react';

interface CardStackProps {
  items: CaseStudy[];
}

export const CardStack: React.FC<CardStackProps> = ({ items }) => {
  return (
    <div className="w-full max-w-5xl mx-auto px-4 flex flex-col gap-8 pb-32">
      {items.map((card, index) => (
        <ListCard key={card.id} card={card} index={index} />
      ))}
    </div>
  );
};

interface ListCardProps {
  card: CaseStudy;
  index: number;
}

const ListCard: React.FC<ListCardProps> = ({ card, index }) => {
  const WistiaPlayer = 'wistia-player' as any;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-10%" }}
      transition={{ 
        duration: 1.2,
        ease: "easeOut",
        delay: index * 0.1
      }}
      className="group relative w-full rounded-3xl border border-white/10 bg-transparent overflow-hidden hover:border-white/20 transition-all hover:shadow-[0_0_30px_rgba(255,255,255,0.05)]"
    >
      <div className="flex flex-col md:flex-row items-stretch">
        {/* Media Section */}
        {card.wistiaId ? (
          <div className="w-full md:w-1/2 relative min-h-[300px] md:min-h-full bg-black/50 border-b md:border-b-0 md:border-r border-white/5">
             {/* Wistia Player Container */}
             <div className="absolute inset-0 flex items-center justify-center overflow-hidden bg-black">
                 <WistiaPlayer 
                   media-id={card.wistiaId} 
                   aspect={card.aspectRatio ? card.aspectRatio.toString() : "0.5625"} 
                   className="w-full h-full object-cover"
                 ></WistiaPlayer>
             </div>
          </div>
        ) : null}

        {/* Content Section */}
        <div className={`p-8 md:p-12 flex flex-col justify-center relative ${card.wistiaId ? 'w-full md:w-1/2' : 'w-full'}`}>
             <div className="flex justify-between items-start mb-8">
                <span className="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest border border-white/10 bg-white/5 text-gray-400 group-hover:text-white transition-colors">
                    {card.tag || 'Testimonial'}
                </span>
                <Quote className="text-brand-red w-8 h-8 opacity-40 group-hover:opacity-100 transition-opacity duration-500 transform rotate-180" />
            </div>

            <p className="text-xl md:text-2xl text-gray-300 font-light leading-relaxed mb-10 group-hover:text-white transition-colors">
                "{card.description}"
            </p>

            <div className="mt-auto pt-6 border-t border-white/5 flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-white/5 border border-white/10 flex items-center justify-center text-lg font-bold text-white/60 group-hover:text-white group-hover:border-brand-red/50 transition-all">
                    {card.title.charAt(0)}
                </div>
                <div>
                    <h4 className="text-white font-medium text-base">{card.title}</h4>
                    <p className="text-brand-red text-xs font-bold uppercase tracking-wide opacity-80">{card.company}</p>
                </div>
            </div>

            {card.stats && (
                <div className="grid grid-cols-3 gap-4 mt-8">
                    {card.stats.map((stat, i) => (
                        <div key={i} className="text-center p-3 rounded-xl bg-white/5 border border-white/5 hover:bg-white/10 transition-colors">
                            <div className="text-white font-bold text-lg">{stat.value}</div>
                            <div className="text-[10px] text-gray-500 uppercase mt-1 tracking-wider">{stat.label}</div>
                        </div>
                    ))}
                </div>
            )}
        </div>
      </div>
    </motion.div>
  );
};