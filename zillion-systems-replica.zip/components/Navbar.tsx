import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { Button } from './Button';

interface NavbarProps {
  onOpenROI?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onOpenROI }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'About Us', href: '#about' },
    { name: 'Case Studies', href: '#case-studies' },
    { name: 'ROI Calculator', href: '#roi' },
  ];

  const bookingLink = "https://zillionsystems.fillout.com/intro-call-with-zillion-systems";

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, linkName: string) => {
    if (linkName === 'ROI Calculator' && onOpenROI) {
      e.preventDefault();
      onOpenROI();
      setIsMobileMenuOpen(false);
    } else {
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-black/95 backdrop-blur-xl border-b border-white/10 py-4' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
        <div className="flex items-center">
          <span className="text-2xl font-bold tracking-tighter bg-gradient-to-r from-white via-gray-200 to-gray-500 bg-clip-text text-transparent hover:text-brand-red transition-colors cursor-pointer">
            Zillionsystems
          </span>
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center space-x-8">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              onClick={(e) => handleNavClick(e, link.name)}
              className="text-sm font-medium text-gray-300 hover:text-brand-red transition-colors"
            >
              {link.name}
            </a>
          ))}
          <a 
            href={bookingLink}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-liquid-glass px-6 py-2 rounded-full font-bold text-sm text-white"
          >
            Book a Call
          </a>
        </div>

        {/* Mobile Toggle */}
        <div className="md:hidden">
          <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="text-white hover:text-brand-red transition-colors">
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-black/95 border-b border-white/10 absolute w-full backdrop-blur-xl">
          <div className="px-4 pt-4 pb-8 space-y-4">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="block px-4 py-3 text-lg font-medium text-gray-300 hover:text-white hover:bg-white/5 rounded-lg border border-transparent hover:border-white/10"
                onClick={(e) => handleNavClick(e, link.name)}
              >
                {link.name}
              </a>
            ))}
            <a 
              href={bookingLink}
              target="_blank"
              rel="noopener noreferrer"
              className="block text-center w-full mt-4 btn-liquid-glass text-white px-4 py-4 rounded-lg font-bold text-lg"
            >
              Book a Call
            </a>
          </div>
        </div>
      )}
    </nav>
  );
};
