import { LucideIcon } from 'lucide-react';

export interface Signal {
  title: string;
  description: string;
  icon: LucideIcon;
  color: string;
}

export interface CaseStudy {
  id: string;
  title: string;
  description: string;
  stats: {
    value: string;
    label: string;
  }[];
  image?: string;
}

export interface TimelineStep {
  phase: string;
  title: string;
  description: string;
}

export interface ProcessStep {
  number: number;
  title: string;
  description: string;
  duration: string;
}

export interface FAQItem {
  question: string;
  answer: string;
}