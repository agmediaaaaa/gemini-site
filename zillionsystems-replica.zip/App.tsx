import React from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Signals from './components/Signals';
import CaseStudies from './components/CaseStudies';
import Testimonial from './components/Testimonial';
import Challenges from './components/Challenges';
import Process from './components/Process';
import Timeline from './components/Timeline';
import Deliverables from './components/Deliverables';
import FAQ from './components/FAQ';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-black text-white font-sans selection:bg-brand-500 selection:text-white">
      <Navbar />
      <Hero />
      
      {/* Case Study Teasers */}
      <CaseStudies />
      
      {/* The "iPhone Stack" Feature Section */}
      <Signals />
      
      {/* Testimonial - Pooja Sharma */}
      <Testimonial />
      
      {/* Challenges & Solutions */}
      <Challenges />
      
      {/* The 5-Step Formula */}
      <Process />
      
      {/* The Vertical Timeline (Week 1-4+) */}
      <Timeline />
      
      {/* Deliverables */}
      <Deliverables />
      
      {/* FAQ */}
      <FAQ />
      
      {/* Footer */}
      <Footer />
    </div>
  );
};

export default App;