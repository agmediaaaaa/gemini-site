import React from 'react';
import { CaseStudy } from '../types';
import { ArrowUpRight } from 'lucide-react';
import { motion } from 'framer-motion';

const cases: CaseStudy[] = [
  {
    id: '1',
    title: 'Manufacturing Recruiter',
    description: "Turned 3,800 targeted emails into 17 warm opportunities in just 30 days.",
    stats: [
      { value: '3,800', label: 'Reached' },
      { value: '17', label: 'Qualified Opps' },
      { value: '3x', label: 'Growth' },
    ]
  },
  {
    id: '2',
    title: 'Technical Staffing Firm',
    description: "Generated 10 opportunities worth $30,000 in just one week.",
    stats: [
      { value: '10', label: 'Opps' },
      { value: '$30k', label: 'Pipeline' },
      { value: '7 days', label: 'Timeframe' },
    ]
  },
  {
    id: '3',
    title: 'High-Volume Campaign',
    description: "7 opportunities worth $35,000 from just 250 targeted emails.",
    stats: [
      { value: '7', label: 'Opps' },
      { value: '$35k', label: 'Value' },
      { value: '2.8%', label: 'Conversion' },
    ]
  },
  {
    id: '4',
    title: 'Targeted Campaign',
    description: "26 opportunities worth $130,000 from a targeted campaign over 11 months.",
    stats: [
      { value: '26', label: 'Opps' },
      { value: '$130k', label: 'Revenue' },
      { value: 'Consistent', label: 'Flow' },
    ]
  }
];

const CaseStudies: React.FC = () => {
  return (
    <section id="case-studies" className="py-24 bg-black relative overflow-hidden">
      {/* Ambient Background */}
      <div className="absolute top-1/3 right-0 w-[600px] h-[600px] bg-brand-900/10 rounded-full blur-[120px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-sm font-bold text-brand-500 uppercase tracking-widest mb-4"
          >
            Client Success
          </motion.h2>
          <motion.h3 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-4xl md:text-5xl font-bold text-white"
          >
            Real results. Verified revenue.
          </motion.h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {cases.map((c, i) => (
            <motion.div 
              key={c.id} 
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -5 }}
              className="group relative bg-white/5 border border-white/10 backdrop-blur-sm rounded-3xl p-10 shadow-lg hover:shadow-brand-900/20 hover:border-brand-500/30 transition-all duration-300"
            >
              <div className="flex justify-between items-start mb-8">
                <h4 className="text-2xl font-bold text-white group-hover:text-brand-400 transition-colors">{c.title}</h4>
                <div className="bg-white/10 p-3 rounded-full group-hover:bg-brand-500/20 transition-colors">
                  <ArrowUpRight className="text-gray-400 group-hover:text-brand-500 transition-colors" size={24} />
                </div>
              </div>
              
              <p className="text-gray-400 text-lg mb-10 leading-relaxed font-medium">{c.description}</p>
              
              <div className="grid grid-cols-3 gap-6 border-t border-white/10 pt-8">
                {c.stats.map((stat, idx) => (
                  <div key={idx}>
                    <div className="text-3xl font-bold text-white mb-1">{stat.value}</div>
                    <div className="text-xs font-bold text-gray-500 uppercase tracking-wider">{stat.label}</div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        {/* Quick Stats Strip */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
          className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-6"
        >
          {[
            { val: "1/3", label: "Responses are Positive" },
            { val: "$80k", label: "Generated in 7 Days" },
            { val: "57.1%", label: "Positive Reply Rate" },
            { val: "300%", label: "Client Pipeline Growth" }
          ].map((item, idx) => (
            <div key={idx} className="bg-white/5 backdrop-blur p-8 rounded-3xl text-center border border-white/10 hover:border-white/20 transition-colors">
              <div className="text-brand-500 font-extrabold text-3xl mb-2">{item.val}</div>
              <div className="text-gray-300 font-semibold text-sm">{item.label}</div>
            </div>
          ))}
        </motion.div>

      </div>
    </section>
  );
};

export default CaseStudies;