import React from 'react';
import { Check } from 'lucide-react';
import { motion } from 'framer-motion';

const deliverables = [
  "Fully managed cold-email engine",
  "AI-powered lead gen with 24/7 hiring-signal monitoring",
  "Personalized outreach at scale with AI-written scripts",
  "Custom sequences with ongoing A/B testing",
  "AI decision-maker mapping for precise targeting",
  "Expanded data coverage (reach contacts most vendors miss)",
  "Deliverability monitoring and optimization",
  "Weekly performance reports + bi-weekly KPI review calls",
  "Custom mini-CRM & dashboard to track lead status",
  "Dedicated account manager and 24/7 Slack access",
  "Continuous optimization of copy, targeting, and send times"
];

const Deliverables: React.FC = () => {
  return (
    <section className="py-24 bg-black text-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-brand-900/20 rounded-full blur-[128px] pointer-events-none"></div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-brand-500 font-bold tracking-widest uppercase mb-6">What's Included</h2>
            <h3 className="text-4xl md:text-5xl font-bold mb-8 text-white">Hiring Signal Engine Deliverables</h3>
            <p className="text-gray-400 text-xl mb-10 leading-relaxed">
              Everything you need to scale your staffing agency without hiring more sales staff or spending hours on manual outreach.
            </p>
            <button className="bg-white text-black px-10 py-5 rounded-2xl font-bold hover:bg-brand-50 transition-colors w-full sm:w-auto shadow-[0_0_30px_rgba(255,255,255,0.2)]">
              Book an Intro Call 📅
            </button>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-[2rem] p-10 hover:bg-white/10 transition-colors"
          >
            <ul className="space-y-5">
              {deliverables.map((item, index) => (
                <motion.li 
                    key={index} 
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="flex items-start gap-4"
                >
                  <div className="mt-1 bg-brand-600 p-1.5 rounded-full text-white shrink-0">
                    <Check size={14} strokeWidth={3} />
                  </div>
                  <span className="text-gray-200 text-lg font-medium">{item}</span>
                </motion.li>
              ))}
            </ul>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Deliverables;