import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black text-slate-400 py-12 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center gap-8">
        <div className="text-2xl font-bold tracking-tighter text-white">
            Zillion<span className="text-brand-600">Systems</span>
        </div>
        
        <div className="text-xs text-slate-600 text-center md:text-right">
          <p>&copy; 2025 SMPAJG Zillion Systems Agency LLP.</p>
          <p>All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;