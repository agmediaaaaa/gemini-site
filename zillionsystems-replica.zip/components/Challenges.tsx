import React from 'react';
import { XCircle, CheckCircle, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

const Challenges: React.FC = () => {
  return (
    <section className="py-24 bg-black border-t border-white/5 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20">
          <h2 className="text-4xl font-bold text-white mb-6">Challenges & Solutions</h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto">See how our system addresses the common challenges faced by modern staffing firms.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-20">
          {/* Challenges */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-red-900/10 rounded-[2rem] p-10 border border-red-900/30"
          >
            <h3 className="text-2xl font-bold text-red-500 mb-8 flex items-center">
              <XCircle className="mr-3" size={28} /> Common Challenges
            </h3>
            <ul className="space-y-8">
              <li className="flex items-start gap-4">
                <div className="mt-2 w-2 h-2 bg-red-500 rounded-full shrink-0"></div>
                <p className="text-gray-300 text-lg font-medium leading-relaxed">Spending hours every single day on manual outreach to generate more leads/business.</p>
              </li>
              <li className="flex items-start gap-4">
                <div className="mt-2 w-2 h-2 bg-red-500 rounded-full shrink-0"></div>
                <p className="text-gray-300 text-lg font-medium leading-relaxed">The leads you get compare you to other recruitment firms making it tough to charge premium rates.</p>
              </li>
              <li className="flex items-start gap-4">
                <div className="mt-2 w-2 h-2 bg-red-500 rounded-full shrink-0"></div>
                <p className="text-gray-300 text-lg font-medium leading-relaxed">No other 'streams' of getting new business besides referrals and in-person events.</p>
              </li>
            </ul>
          </motion.div>

          {/* Solutions */}
          <motion.div 
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="bg-green-900/10 rounded-[2rem] p-10 border border-green-900/30 shadow-xl shadow-green-900/10"
          >
            <h3 className="text-2xl font-bold text-green-500 mb-8 flex items-center">
              <CheckCircle className="mr-3" size={28} /> Our Solutions
            </h3>
            <ul className="space-y-8">
              <li className="flex items-start gap-4">
                <div className="mt-2 w-2 h-2 bg-green-500 rounded-full shrink-0"></div>
                <p className="text-gray-200 text-lg font-medium leading-relaxed">Zero time spent on manual outreach as we automate everything.</p>
              </li>
              <li className="flex items-start gap-4">
                <div className="mt-2 w-2 h-2 bg-green-500 rounded-full shrink-0"></div>
                <p className="text-gray-200 text-lg font-medium leading-relaxed">Charge premium rates by turning your offer into a one-off in the space.</p>
              </li>
              <li className="flex items-start gap-4">
                <div className="mt-2 w-2 h-2 bg-green-500 rounded-full shrink-0"></div>
                <p className="text-gray-200 text-lg font-medium leading-relaxed">2-3 new streams to bring in more deals for you consistently.</p>
              </li>
            </ul>
          </motion.div>
        </div>

        {/* Comparison Table */}
        <motion.div 
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="bg-white/5 rounded-3xl shadow-2xl border border-white/10 overflow-hidden backdrop-blur-sm"
        >
          <div className="grid grid-cols-4 bg-white/10 text-white p-6 text-lg font-bold">
            <div className="col-span-1">Metric</div>
            <div className="col-span-1 text-center">Before</div>
            <div className="col-span-1 text-center text-green-500">After</div>
            <div className="col-span-1 text-right">Improvement</div>
          </div>
          
          {[
            { metric: "Weekly Outreach", before: "20+ hours", after: "0 hours", improvement: "100% Reduction", color: "text-green-500" },
            { metric: "Response Rate", before: "2-3%", after: "5-8%", improvement: "~3x Boost", color: "text-green-500" },
            { metric: "Qualified Opps", before: "3-4 /mo", after: "8-12 /mo", improvement: "300% Increase", color: "text-green-500" },
            { metric: "Lead Speed", before: "24 hours", after: "0-15 mins", improvement: "95% Faster", color: "text-green-500" },
          ].map((row, idx) => (
            <motion.div 
              key={idx} 
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ delay: 0.2 + idx * 0.1 }}
              className="grid grid-cols-4 p-6 border-b border-white/5 hover:bg-white/5 transition-colors items-center text-lg"
            >
              <div className="col-span-1 font-bold text-gray-200">{row.metric}</div>
              <div className="col-span-1 text-center text-gray-500 font-medium">{row.before}</div>
              <div className="col-span-1 text-center font-extrabold text-white bg-brand-900/30 py-1 rounded-lg border border-brand-500/20">{row.after}</div>
              <div className={`col-span-1 text-right font-bold ${row.color}`}>{row.improvement}</div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Challenges;