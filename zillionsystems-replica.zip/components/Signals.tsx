import React from 'react';
import { motion } from 'framer-motion';
import { 
  Briefcase, 
  TrendingUp, 
  MapPin, 
  Award, 
  Users, 
  Globe, 
  AlertCircle, 
  Building2,
  Frown,
  ArrowRight
} from 'lucide-react';
import { Signal } from '../types';

const signals: Signal[] = [
  {
    title: "Companies with open jobs",
    description: "Actively hiring for specialized positions.",
    icon: Briefcase,
    color: "text-brand-500 bg-brand-900/20"
  },
  {
    title: "Rapid Headcount Growth",
    description: "Firms rapidly increasing headcount.",
    icon: TrendingUp,
    color: "text-brand-500 bg-brand-900/20"
  },
  {
    title: "New Office / Launches",
    description: "New office openings and products.",
    icon: MapPin,
    color: "text-brand-500 bg-brand-900/20"
  },
  {
    title: "Recently Funded",
    description: "Growth mode companies needing talent.",
    icon: Award,
    color: "text-brand-500 bg-brand-900/20"
  },
  {
    title: "Leadership Changes",
    description: "New executives bring new initiatives.",
    icon: Users,
    color: "text-brand-500 bg-brand-900/20"
  },
  {
    title: "Mergers & Acquisitions",
    description: "Talent needed to manage transitions.",
    icon: Building2,
    color: "text-brand-500 bg-brand-900/20"
  },
  {
    title: "Geographic Expansion",
    description: "Establishing local teams in new markets.",
    icon: Globe,
    color: "text-brand-500 bg-brand-900/20"
  },
  {
    title: "Poor Job Board Ratings",
    description: "Struggling with direct hiring.",
    icon: Frown,
    color: "text-brand-500 bg-brand-900/20"
  },
  {
    title: "Employee Turnover",
    description: "High turnover signals immediate needs.",
    icon: AlertCircle,
    color: "text-brand-500 bg-brand-900/20"
  }
];

const Signals: React.FC = () => {
  return (
    <section className="py-32 bg-black relative overflow-hidden">
      {/* Ambient Background Glow */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-0 w-[500px] h-[500px] bg-brand-600/20 rounded-full blur-[120px] animate-pulse"></div>
        <div className="absolute bottom-0 right-0 w-[600px] h-[600px] bg-red-600/20 rounded-full blur-[120px] animate-pulse animation-delay-2000"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-2 gap-20 items-center relative z-10">
        
        {/* Text Content */}
        <motion.div 
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="order-2 lg:order-1"
        >
          <div className="flex items-center gap-3 mb-6">
            <span className="h-px w-12 bg-brand-500"></span>
            <span className="text-brand-500 font-bold tracking-widest uppercase text-sm">Relevance Engine</span>
          </div>
          
          <h3 className="text-4xl md:text-6xl font-bold text-white mb-8 leading-tight">
            Reach companies with <span className="text-brand-500">urgent needs</span>
          </h3>
          
          <p className="text-gray-300 text-xl mb-10 leading-relaxed font-light">
            Our system allows you to ONLY reach out to companies having urgent hiring needs. Stop wasting time on cold leads.
          </p>

          <ul className="space-y-6">
             {signals.slice(0,3).map((s, i) => (
               <motion.li 
                key={i} 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="flex items-center gap-4 text-gray-200 bg-white/5 p-4 rounded-xl border border-white/10 hover:bg-white/10 transition-colors cursor-default"
               >
                 <div className={`p-3 rounded-lg ${s.color}`}>
                   <s.icon size={20} />
                 </div>
                 <span className="font-medium text-lg">{s.title}</span>
               </motion.li>
             ))}
          </ul>
          
          <motion.div 
            className="mt-12"
            whileHover={{ x: 10 }}
          >
            <button className="text-white flex items-center gap-2 text-lg font-semibold group">
              View all 9 signals 
              <ArrowRight className="group-hover:text-brand-500 transition-colors" size={20} />
            </button>
          </motion.div>
        </motion.div>

        {/* Interactive Visual Component (iPhone Stack) */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.9, rotate: -5 }}
          whileInView={{ opacity: 1, scale: 1, rotate: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="order-1 lg:order-2 relative h-[700px] w-full max-w-md mx-auto"
        >
            {/* Glass Reflection Layer Behind */}
            <div className="absolute inset-0 bg-gradient-to-tr from-brand-600/20 to-red-600/20 blur-3xl transform rotate-12 scale-110"></div>

            {/* Phone Frame */}
            <div className="relative h-full w-full bg-gray-900/80 backdrop-blur-2xl rounded-[3rem] border-8 border-gray-800 shadow-2xl overflow-hidden z-20 ring-1 ring-white/20">
                {/* Top Bar */}
                <div className="absolute top-0 left-0 right-0 h-14 bg-black/50 z-30 flex justify-center pt-3">
                   <div className="w-32 h-7 bg-black rounded-full"></div>
                </div>

                {/* Scroll Area */}
                <div className="h-full w-full pt-16 px-4 pb-8 relative">
                    {/* Infinite Scroll Animation */}
                    <motion.div 
                        className="flex flex-col gap-4"
                        animate={{ y: [0, -1300] }}
                        transition={{
                            repeat: Infinity,
                            duration: 30,
                            ease: "linear"
                        }}
                    >
                        {[...signals, ...signals, ...signals].map((signal, idx) => (
                            <div 
                                key={idx}
                                className="bg-white/10 backdrop-blur-xl border border-white/10 p-5 rounded-2xl shadow-lg flex items-start gap-4 hover:bg-white/20 transition-all duration-300 group"
                            >
                                <div className={`p-3 rounded-xl shrink-0 ${signal.color} transition-transform`}>
                                    <signal.icon size={24} />
                                </div>
                                <div>
                                    <h4 className="text-white font-bold text-base mb-1">{signal.title}</h4>
                                    <p className="text-gray-400 text-sm leading-snug font-medium">{signal.description}</p>
                                </div>
                            </div>
                        ))}
                    </motion.div>
                    
                    {/* Fade Gradients */}
                    <div className="absolute top-14 left-0 right-0 h-24 bg-gradient-to-b from-gray-900 via-gray-900/80 to-transparent z-10 pointer-events-none"></div>
                    <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-gray-900 via-gray-900/90 to-transparent z-10 pointer-events-none"></div>
                </div>
            </div>
        </motion.div>

      </div>
    </section>
  );
};

export default Signals;