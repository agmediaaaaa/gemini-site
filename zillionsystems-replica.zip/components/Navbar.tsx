import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${scrolled ? 'bg-black/80 backdrop-blur-md border-b border-white/10 py-4' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
        <div className="flex items-center">
          <span className="text-2xl font-bold tracking-tighter text-white">
            Zillion<span className="text-brand-600">Systems</span>
          </span>
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center space-x-8">
          <a href="#about" className="text-gray-300 font-medium hover:text-white transition-colors">About Us</a>
          <a href="#case-studies" className="text-gray-300 font-medium hover:text-white transition-colors">Case Studies</a>
          <a href="#roi" className="text-gray-300 font-medium hover:text-white transition-colors">ROI Calculator</a>
          <button className="bg-brand-600 text-white px-6 py-2.5 rounded-full font-bold hover:bg-brand-700 transition-all transform hover:-translate-y-0.5 shadow-lg shadow-brand-900/50 ring-1 ring-brand-500/50">
            Book a Call
          </button>
        </div>

        {/* Mobile Menu Button */}
        <div className="md:hidden">
          <button onClick={() => setIsOpen(!isOpen)} className="text-white">
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-black/95 border-b border-gray-800 p-4 flex flex-col space-y-4 shadow-lg backdrop-blur-xl">
          <a href="#about" className="text-gray-300 font-medium hover:text-white" onClick={() => setIsOpen(false)}>About Us</a>
          <a href="#case-studies" className="text-gray-300 font-medium hover:text-white" onClick={() => setIsOpen(false)}>Case Studies</a>
          <a href="#roi" className="text-gray-300 font-medium hover:text-white" onClick={() => setIsOpen(false)}>ROI Calculator</a>
          <button className="bg-brand-600 text-white px-6 py-3 rounded-lg font-bold w-full">
            Book a Call
          </button>
        </div>
      )}
    </nav>
  );
};

export default Navbar;