import React, { useState } from 'react';
import { Plus, Minus } from 'lucide-react';
import { FAQItem } from '../types';

const faqs: FAQItem[] = [
  {
    question: "How does your AI-based cold email system work?",
    answer: "We use proprietary AI to scan thousands of data points for hiring signals (like funding, job posts, or growth). We then verify decision-maker data and send highly personalized emails at scale, managing the entire inbox infrastructure for you."
  },
  {
    question: "How long until I see results?",
    answer: "Most clients see their first qualified meetings booked within 2-3 weeks of the campaign launch. Our 'Launch Prep' phase ensures we hit the ground running with high deliverability."
  },
  {
    question: "Do I need to provide my own email list?",
    answer: "No. We handle all data sourcing. Our system builds a dynamic list of your Ideal Customer Profile (ICP) based on real-time hiring signals."
  },
  {
    question: "What makes your system different from other lead generation services?",
    answer: "Unlike generic lead gen shops that blast generic lists, we focus strictly on 'Timing' and 'Relevance'. We only contact companies actively exhibiting signals that they need help now."
  },
  {
    question: "How do you ensure emails don't get marked as spam?",
    answer: "We build a dedicated secondary domain infrastructure and warm it up properly before sending. We monitor sender reputation daily and rotate domains if necessary to protect your primary brand."
  },
  {
    question: "What kind of support do you provide?",
    answer: "You get a dedicated account manager, bi-weekly strategy calls, and a private Slack channel for 24/7 communication."
  }
];

const FAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <section className="py-20 bg-black relative">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-white">Frequently Asked Questions</h2>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div key={index} className="border border-white/10 rounded-2xl overflow-hidden bg-white/5 backdrop-blur-sm">
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between p-6 text-left hover:bg-white/5 transition-colors"
              >
                <span className="font-semibold text-white pr-8">{faq.question}</span>
                {openIndex === index ? (
                  <Minus className="text-brand-500 flex-shrink-0" size={20} />
                ) : (
                  <Plus className="text-gray-500 flex-shrink-0" size={20} />
                )}
              </button>
              
              <div 
                className={`transition-all duration-300 ease-in-out overflow-hidden ${
                  openIndex === index ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
                }`}
              >
                <div className="p-6 pt-0 text-gray-400 leading-relaxed border-t border-white/5">
                  {faq.answer}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;