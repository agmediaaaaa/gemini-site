import React from 'react';
import { Quote } from 'lucide-react';
import { motion } from 'framer-motion';

const Testimonial: React.FC = () => {
  return (
    <section className="py-24 bg-black relative overflow-hidden">
       <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-red-900/10 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="bg-white/5 border border-white/10 backdrop-blur-xl rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col md:flex-row"
        >
          <div className="md:w-2/5 bg-brand-900 relative overflow-hidden min-h-[400px] md:min-h-0 group">
            <img 
              src="https://picsum.photos/seed/pooja/800/1000?grayscale" 
              alt="Pooja Sharma" 
              className="absolute inset-0 w-full h-full object-cover opacity-60 mix-blend-overlay group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-brand-900/50 to-transparent"></div>
            <div className="absolute bottom-10 left-10 text-white z-10">
              <div className="font-bold text-2xl mb-2">Pooja Sharma</div>
              <div className="text-brand-200 font-medium">Founder & CEO</div>
              <div className="text-brand-300 text-sm uppercase tracking-widest mt-1">The Talent Mappers</div>
            </div>
          </div>
          
          <div className="md:w-3/5 p-10 md:p-16 flex flex-col justify-center relative">
            <Quote className="absolute top-10 right-10 text-white/5 rotate-12" size={100} />
            
            <h3 className="text-3xl font-bold text-white mb-8 relative z-10 leading-tight">
              "From Exhausted Networks to Consistent Leads"
            </h3>
            
            <div className="space-y-6 text-gray-300 text-lg relative z-10 font-medium leading-relaxed">
              <p>
                "At the beginning of 2025, I was at a stage where I had exhausted all my networks and referrals. I was hesitant because me being a non-technical person wasn't sure if this is the right path for me."
              </p>
              <p>
                "Zillion Systems made it simple. Their processes are genuinely result-driven. I started to see new leads coming in just in a few weeks and <span className="text-brand-400 bg-brand-900/30 px-1">my business took off from there.</span>"
              </p>
            </div>

            <div className="mt-10">
               <button className="text-brand-500 font-bold hover:text-brand-400 inline-flex items-center text-lg group">
                 Read full success story 
                 <span className="ml-2 transform group-hover:translate-x-1 transition-transform">→</span>
               </button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Testimonial;