import React, { useRef } from 'react';
import { motion, useScroll, useSpring } from 'framer-motion';
import { TimelineStep } from '../types';

const steps: TimelineStep[] = [
  {
    phase: "Week 1-2",
    title: "Foundation",
    description: "We finalize your Custom Offer and Guarantee and begin building your dedicated email infrastructure."
  },
  {
    phase: "Week 2-3",
    title: "Launch Prep",
    description: "You Approve the Messaging and we load the first batch of Triple-Qualified Leads into the system."
  },
  {
    phase: "Week 3-4",
    title: "First Appointments",
    description: "Your calendar begins to fill with Qualified Hiring Manager Meetings. We review the first week's performance."
  },
  {
    phase: "Week 4+",
    title: "Scale",
    description: "We continuously optimize to hit your target of 3-5 new job orders monthly, multiplying your revenue."
  }
];

const Timeline: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  const scaleY = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  return (
    <section className="py-24 bg-black relative overflow-hidden" ref={containerRef}>
        <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-orange-900/10 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-24">
          <h2 className="text-brand-500 font-bold tracking-widest text-sm uppercase mb-4">Execution Roadmap</h2>
          <h3 className="text-4xl font-bold text-white">The Path to Signed Orders</h3>
        </div>

        <div className="relative max-w-4xl mx-auto">
          {/* The Central Vertical Line */}
          <div className="absolute left-[20px] md:left-1/2 top-0 bottom-0 w-1 bg-white/10 -translate-x-1/2 origin-top"></div>
          
          {/* The Animated Fill Line */}
          <motion.div 
            style={{ scaleY, transformOrigin: 'top' }}
            className="absolute left-[20px] md:left-1/2 top-0 bottom-0 w-1 bg-brand-600 -translate-x-1/2 z-0"
          ></motion.div>

          <div className="space-y-12 md:space-y-24">
            {steps.map((step, index) => (
              <TimelineCard key={index} step={step} index={index} />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const TimelineCard: React.FC<{ step: TimelineStep; index: number }> = ({ step, index }) => {
  const isEven = index % 2 === 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className={`relative flex flex-col md:flex-row items-center ${
        isEven ? 'md:flex-row-reverse' : ''
      }`}
    >
      {/* The Dot */}
      <div className="absolute left-[20px] md:left-1/2 top-0 w-8 h-8 bg-black border-[6px] border-brand-600 rounded-full -translate-x-1/2 z-10 shadow-[0_0_20px_rgba(225,29,72,0.5)] mt-6 md:mt-0"></div>

      {/* Spacer */}
      <div className="flex-1 w-full md:w-1/2"></div>

      {/* Content Card */}
      <div className="flex-1 w-full md:w-1/2 pl-16 md:pl-0 md:px-16">
        <div className={`bg-white/5 backdrop-blur-sm p-8 rounded-2xl shadow-lg border border-white/10 hover:border-brand-500/30 hover:bg-white/10 transition-all duration-300 relative ${
            !isEven ? 'md:text-right' : ''
        }`}>
          <span className="inline-block px-4 py-1 bg-brand-600 text-white text-xs font-bold rounded-full mb-5 shadow-lg">
            {step.phase}
          </span>
          <h4 className="text-2xl font-bold text-white mb-4">{step.title}</h4>
          <p className="text-gray-400 leading-relaxed font-medium">{step.description}</p>
        </div>
      </div>
    </motion.div>
  );
};

export default Timeline;